module Typhoeus

  # The current Typhoeus version.
  VERSION = '0.6.9'
end
