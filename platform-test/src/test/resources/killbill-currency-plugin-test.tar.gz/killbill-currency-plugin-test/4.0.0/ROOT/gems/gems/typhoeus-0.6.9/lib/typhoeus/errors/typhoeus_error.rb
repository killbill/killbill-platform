module Typhoeus
  module Errors

    # Default typhoeus error class for all custom errors.
    class TyphoeusError < StandardError
    end
  end
end
