:<%= identifier %>:
  :test: true

:database:
# SQLite (development)
  :adapter: sqlite3
  :database: test.db
# For MySQL
#  :adapter: mysql
#  :username: 'killbill'
#  :password: 'killbill'
#  :database: 'killbill' # or set the URL :
#  #:url: jdbc:mysql://127.0.0.1:3306/killbill
#  :driver: org.mariadb.jdbc.Driver # as in KB
#  :pool: 30 # AR's default is max 5 connections
# In Kill Bill
#  :adapter: mysql
#  :jndi: 'killbill/osgi/jdbc'
#  :pool: false # false-pool (JNDI pool's max)
#  # uncomment if pool does not support JDBC4 :
#  #:connection_alive_sql: 'select 1'
#  # MySQL adapter #configure_connection defaults :
#  #    @@SESSION.sql_auto_is_null = 0,
#  #    @@SESSION.wait_timeout = 2147483,
#  #    @@SESSION.sql_mode = 'STRICT_ALL_TABLES'
#  # ... can be disabled (on AR-JDBC 1.4) using :
#  :configure_connection: false
