module Killbill
  VERSION = '6.0.0'
end
