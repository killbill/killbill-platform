#!/usr/bin/env ruby
# -*- ruby -*-

$:.unshift '../../lib'
require 'rack'
Rack::Server.start
