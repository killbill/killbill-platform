killbill-currency-plugin
========================

A currency plugin used for integration tests.

Release builds are available on [Maven Central](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22com.ning.killbill.ruby%22%20AND%20a%3A%22killbill-currency-plugin-test%22) with coordinates `com.ning.killbill.ruby:killbill-currency-plugin-test`.
