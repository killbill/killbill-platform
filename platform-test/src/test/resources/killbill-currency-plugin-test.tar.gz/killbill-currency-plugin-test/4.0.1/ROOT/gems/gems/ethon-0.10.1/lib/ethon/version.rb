module Ethon

  # Ethon version.
  VERSION = '0.10.1'
end
