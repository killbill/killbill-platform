module Killbill
  VERSION = '6.2.0'
end
