module Ethon

  # Ethon version.
  VERSION = '0.7.3'
end
