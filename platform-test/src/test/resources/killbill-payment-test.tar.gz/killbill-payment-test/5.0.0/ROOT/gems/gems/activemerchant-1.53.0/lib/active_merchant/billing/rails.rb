require "active_merchant/billing/compatibility"

ActiveMerchant::Billing::Compatibility.rails_required!
