module ActiveMerchant
  VERSION = "1.53.0"
end
