module ActionView
  module Helpers
    module Tags # :nodoc:
      class RangeField < NumberField # :nodoc:
      end
    end
  end
end
