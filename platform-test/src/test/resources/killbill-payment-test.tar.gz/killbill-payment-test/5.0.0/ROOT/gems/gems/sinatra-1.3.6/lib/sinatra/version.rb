module Sinatra
  VERSION = '1.3.6'
end
