module Killbill #:nodoc:
  module <%= class_name %> #:nodoc:
    class PrivatePaymentPlugin < ::Killbill::Plugin::ActiveMerchant::PrivatePaymentPlugin
    end
  end
end
