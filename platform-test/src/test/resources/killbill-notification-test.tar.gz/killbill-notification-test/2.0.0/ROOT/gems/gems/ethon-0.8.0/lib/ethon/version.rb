module Ethon

  # Ethon version.
  VERSION = '0.8.0'
end
