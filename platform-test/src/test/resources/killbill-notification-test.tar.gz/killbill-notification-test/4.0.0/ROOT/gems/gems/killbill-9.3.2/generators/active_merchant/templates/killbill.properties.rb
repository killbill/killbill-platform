mainClass=Killbill::<%= class_name %>::PaymentPlugin
require=<%= identifier %>
pluginType=PAYMENT
