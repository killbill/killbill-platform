require 'typhoeus/errors/typhoeus_error'
require 'typhoeus/errors/no_stub'

module Typhoeus

  # This namespace contains all errors raised by Typhoeus.
  module Errors
  end
end
