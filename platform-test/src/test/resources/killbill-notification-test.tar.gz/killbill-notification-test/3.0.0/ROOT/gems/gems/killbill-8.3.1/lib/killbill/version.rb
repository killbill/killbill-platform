module Killbill
  VERSION = '8.3.1'
end
