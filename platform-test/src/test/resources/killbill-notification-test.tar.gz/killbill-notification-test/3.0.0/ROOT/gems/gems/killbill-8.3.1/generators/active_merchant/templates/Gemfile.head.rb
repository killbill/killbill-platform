source 'https://rubygems.org'

gemspec

gem 'killbill', :github => 'killbill/killbill-plugin-framework-ruby', :ref => 'HEAD'
